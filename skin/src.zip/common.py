WINDOW_WIDTH         =        680
WINDOW_HEIGHT        =         372
WINDOW_START_X       =       	0
WINDOW_START_Y       =      	0
WINDOW_PAGE_COUNT    =       	4
WINDOW_BUTTON_COUNT  =   	4
WINDOW_PAGE_MOVE     =     	20
WINDOW_ONEBUTTON_WIDTH = 	170

