<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>AboutUsDialog</name>
    <message>
        <location filename="about_us.cpp" line="100"/>
        <source>title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about_us.cpp" line="101"/>
        <source>360 safe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about_us.cpp" line="102"/>
        <source>info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about_us.cpp" line="103"/>
        <source>version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about_us.cpp" line="104"/>
        <source>mummy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about_us.cpp" line="105"/>
        <source>copyright</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about_us.cpp" line="106"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about_us.cpp" line="107"/>
        <source>ok</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeSkinWidget</name>
    <message>
        <location filename="change_skin_widget.cpp" line="36"/>
        <source>use skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="change_skin_widget.cpp" line="57"/>
        <source>download count:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CharacterWidget</name>
    <message>
        <location filename="character_widget.cpp" line="65"/>
        <source>function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="character_widget.cpp" line="65"/>
        <source>clear cookie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="character_widget.cpp" line="65"/>
        <source>triggerman</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="character_widget.cpp" line="65"/>
        <source>booster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="character_widget.cpp" line="66"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="content_widget.cpp" line="443"/>
        <source>suggest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="444"/>
        <source>system safe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="445"/>
        <source>power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="447"/>
        <source>login home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="448"/>
        <source>show beautifull icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="449"/>
        <source>register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="450"/>
        <source>privilege power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="452"/>
        <source>fireproof</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="453"/>
        <source>triggerman</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="454"/>
        <source>net shop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="456"/>
        <source>function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="457"/>
        <source>more</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="458"/>
        <source>recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="459"/>
        <source>mobile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="460"/>
        <source>game box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="461"/>
        <source>desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="462"/>
        <source>net repair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="463"/>
        <source>auto run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="464"/>
        <source>net speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="465"/>
        <source>net pretext</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="466"/>
        <source>first add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="468"/>
        <source>connect success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="content_widget.cpp" line="469"/>
        <source>version</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainMenu</name>
    <message>
        <location filename="main_menu.cpp" line="48"/>
        <source>setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_menu.cpp" line="49"/>
        <source>new character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_menu.cpp" line="50"/>
        <source>check update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_menu.cpp" line="51"/>
        <source>change company</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_menu.cpp" line="52"/>
        <source>help online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_menu.cpp" line="53"/>
        <source>platform help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_menu.cpp" line="54"/>
        <source>login home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_menu.cpp" line="55"/>
        <source>protect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_menu.cpp" line="56"/>
        <source>about us</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="setting_dialog.cpp" line="369"/>
        <source>360 safe setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="370"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="372"/>
        <source>rise style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="373"/>
        <source>advanced setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="374"/>
        <source>physical setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="375"/>
        <source>user setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="376"/>
        <source>improve program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="377"/>
        <source>cloud secure program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="379"/>
        <source>rise style title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="380"/>
        <source>auto rise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="381"/>
        <source>not auto rise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="382"/>
        <source>rise mummy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="383"/>
        <source>game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="384"/>
        <source>3g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="385"/>
        <source>p2p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="386"/>
        <source>mummy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="388"/>
        <source>mummy fireproof</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="389"/>
        <source>context menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="390"/>
        <source>software manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="391"/>
        <source>auto start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="392"/>
        <source>remove own</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="393"/>
        <source>strong remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="394"/>
        <source>mummy kill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="395"/>
        <source>display count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="397"/>
        <source>frequency setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="398"/>
        <source>quit style setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="399"/>
        <source>auto check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="400"/>
        <source>first check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="401"/>
        <source>hand check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="402"/>
        <source>select quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="403"/>
        <source>backstage mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="404"/>
        <source>immediacy close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="406"/>
        <source>rate task setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="407"/>
        <source>diaplay experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="408"/>
        <source>diaplay login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="409"/>
        <source>tray quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="410"/>
        <source>new character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="411"/>
        <source>rise remind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="413"/>
        <source>improve plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="414"/>
        <source>join improve plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="415"/>
        <source>understand detail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="417"/>
        <source>file safe plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="418"/>
        <source>internet safe plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="419"/>
        <source>file safe info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="420"/>
        <source>internet safe info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="421"/>
        <source>file safe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="422"/>
        <source>internet safe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="423"/>
        <source>look privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="425"/>
        <source>ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="setting_dialog.cpp" line="426"/>
        <source>cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SkinWidget</name>
    <message>
        <location filename="skin_widget.cpp" line="245"/>
        <source>blue sea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="245"/>
        <source>red heart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="245"/>
        <source>lovely baby</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="245"/>
        <source>transparent water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="246"/>
        <source>flower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="246"/>
        <source>great sunshine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="246"/>
        <source>shadow amazement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="245"/>
        <source>profound life</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="246"/>
        <source>360 pet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="246"/>
        <source>beautiful stone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="247"/>
        <source>yellow energy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="247"/>
        <source>magic world</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="247"/>
        <source>intense emotion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="247"/>
        <source>dream sky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="247"/>
        <source>angry bird</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="248"/>
        <source>graceful jazz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="248"/>
        <source>card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="248"/>
        <source>summer cool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="248"/>
        <source>blue world</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="248"/>
        <source>woodwind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="249"/>
        <source>pink mood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="249"/>
        <source>across time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="249"/>
        <source>six year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="140"/>
        <source>first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="141"/>
        <source>previous page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="142"/>
        <source>next page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="143"/>
        <source>last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="242"/>
        <source>title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="skin_widget.cpp" line="243"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemTray</name>
    <message>
        <location filename="system_tray.cpp" line="18"/>
        <source>360 safe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="20"/>
        <source>open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="21"/>
        <source>help center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="22"/>
        <source>kill mummy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="23"/>
        <source>clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="24"/>
        <source>optimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="25"/>
        <source>fireproof</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="26"/>
        <source>show speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="27"/>
        <source>soft manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="28"/>
        <source>safe notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="29"/>
        <source>rise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="30"/>
        <source>login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="31"/>
        <source>separate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="system_tray.cpp" line="32"/>
        <source>logout</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="title_widget.cpp" line="95"/>
        <source>title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="96"/>
        <source>change skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="97"/>
        <source>main menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="98"/>
        <source>minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="99"/>
        <source>maximize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="100"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="102"/>
        <source>power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="103"/>
        <source>mummy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="104"/>
        <source>hole</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="105"/>
        <source>repair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="106"/>
        <source>clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="107"/>
        <source>optimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="108"/>
        <source>expert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="title_widget.cpp" line="109"/>
        <source>software</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
